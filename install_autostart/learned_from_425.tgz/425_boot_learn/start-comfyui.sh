#!/bin/bash

# ComfyUI 启动脚本 (改进版)
# 确保使用正确的 Python 路径和环境变量
# 添加错误处理和日志输出

set -e  # 遇到错误立即退出

# 日志函数
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') - $1" >&2
}

log_warn() {
    echo "[WARN] $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

# 设置环境变量
export PATH="/usr/local/bin:/root/miniconda3/bin:$PATH"
log_info "设置 PATH: $PATH"

# 设置库路径，优先使用 conda 环境中的 TBB（版本 2022.3.0，满足 Numba 要求）
# 这可以解决 Numba TBB 线程层警告：TBB_INTERFACE_VERSION >= 12060
if [ -z "$LD_LIBRARY_PATH" ]; then
    export LD_LIBRARY_PATH="/root/miniconda3/lib"
else
    export LD_LIBRARY_PATH="/root/miniconda3/lib:$LD_LIBRARY_PATH"
fi
log_info "设置 LD_LIBRARY_PATH: $LD_LIBRARY_PATH"

# 检查 Python 是否存在
if [ ! -f "/root/miniconda3/bin/python" ]; then
    log_error "Python 未找到: /root/miniconda3/bin/python"
    exit 1
fi

# 检查 ComfyUI 目录是否存在
if [ ! -d "/root/ComfyUI" ]; then
    log_error "ComfyUI 目录不存在: /root/ComfyUI"
    exit 1
fi

# 进入 ComfyUI 目录
cd /root/ComfyUI || {
    log_error "无法进入 ComfyUI 目录"
    exit 1
}
log_info "当前工作目录: $(pwd)"

# 检查 main.py 是否存在
if [ ! -f "main.py" ]; then
    log_error "main.py 文件不存在"
    exit 1
fi

# 清理可能存在的 .ipynb_checkpoints 目录（Jupyter notebook 检查点）
# 用户安装插件时可能会自动产生此目录，需要清理以避免问题
if [ -d "custom_nodes/.ipynb_checkpoints" ]; then
    log_info "清理 .ipynb_checkpoints 目录..."
    rm -rf custom_nodes/.ipynb_checkpoints
fi

# 注意：模型和插件目录已经挂载，无需创建符号链接或修改插件目录

# 同步远程工作流文件（如果远程文件存在）
REMOTE_WORKFLOW="/.autodl/users/9/98101/Wan2.2Animate-dzqyV2.json"
LOCAL_WORKFLOW="/root/zealman-app/dist/Wan2.2Animate-dzqyV2.json"
if [ -f "$REMOTE_WORKFLOW" ]; then
    log_info "同步工作流文件: $REMOTE_WORKFLOW -> $LOCAL_WORKFLOW"
    # 确保目标目录存在
    LOCAL_DIR=$(dirname "$LOCAL_WORKFLOW")
    if [ ! -d "$LOCAL_DIR" ]; then
        log_info "创建目录: $LOCAL_DIR"
        mkdir -p "$LOCAL_DIR"
    fi
    # 复制文件
    if cp "$REMOTE_WORKFLOW" "$LOCAL_WORKFLOW" 2>/dev/null; then
        log_info "工作流文件同步成功"
    else
        log_warn "工作流文件同步失败，但继续启动 ComfyUI"
    fi
else
    log_info "远程工作流文件不存在，跳过同步: $REMOTE_WORKFLOW"
fi

# 更新模型符号链接（如果更新脚本存在）
if [ -f "/.autodl/users/9/98101/update-symlinks.sh" ]; then
    log_info "更新模型符号链接..."
    set +e  # 临时禁用错误退出，确保符号链接更新失败不影响 ComfyUI 启动
    bash /.autodl/users/9/98101/update-symlinks.sh
    SYMLINK_EXIT_CODE=$?
    set -e
    if [ $SYMLINK_EXIT_CODE -eq 0 ]; then
        log_info "模型符号链接更新完成"
    else
        log_warn "模型符号链接更新过程中出现错误，但继续启动 ComfyUI"
    fi
else
    log_info "模型符号链接更新脚本不存在，跳过: /.autodl/users/9/98101/update-symlinks.sh"
fi

# 检查端口是否被占用
PORT=6006
# 临时禁用 set -e，检查端口占用情况
set +e
PORT_IN_USE=$(lsof -Pi :$PORT -sTCP:LISTEN -t 2>/dev/null)
PORT_CHECK_EXIT=$?
set -e

if [ $PORT_CHECK_EXIT -eq 0 ] && [ -n "$PORT_IN_USE" ]; then
    log_warn "端口 $PORT 已被占用，尝试终止占用进程..."
    set +e
    echo "$PORT_IN_USE" | xargs kill -9 2>/dev/null || true
    set -e
    sleep 2
fi

# 启动 ComfyUI
log_info "启动 ComfyUI..."
log_info "Python 版本: $(/root/miniconda3/bin/python --version)"
log_info "监听地址: 127.0.0.1:$PORT"

# 使用 nohup 在后台运行，并重定向输出到日志文件
LOG_FILE="/root/ComfyUI/user/comfyui-startup.log"
log_info "日志文件: $LOG_FILE"

# 启动 ComfyUI（前台运行，便于查看输出）
# 注意：如果需要后台运行，请使用 nohup 或 systemd 服务
# 使用 set +e 确保即使 tee 或 Python 进程退出也不会导致脚本立即退出
set +e
/root/miniconda3/bin/python main.py --port $PORT --listen 127.0.0.1 --enable-cors-header "*" 2>&1 | tee -a "$LOG_FILE"
EXIT_CODE=${PIPESTATUS[0]}
set -e

if [ $EXIT_CODE -ne 0 ]; then
    log_error "ComfyUI 启动失败，退出码: $EXIT_CODE"
    exit $EXIT_CODE
fi