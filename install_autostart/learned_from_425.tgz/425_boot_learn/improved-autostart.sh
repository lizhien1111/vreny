#!/bin/bash
# Zealman-AutoDL 改进的自动启动脚本
# 支持多种启动方式，确保服务可靠启动

set -e

# 设置 PATH 确保使用系统级 Node.js
export PATH="/usr/local/bin:/usr/bin:/bin:$PATH"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_message() {
    echo -e "${1}${2}${NC}"
}

LOG_FILE="/tmp/zealman-app-improved-autostart.log"
LOCK_FILE="/tmp/zealman-app-improved-autostart.lock"

# 日志函数
log_message() {
    echo "$(date '+%Y-%m-%d %H:%M:%S'): $1" >> "$LOG_FILE"
    print_message $BLUE "$1"
}

# 检查服务是否运行
check_service() {
    if lsof -i :6008 >/dev/null 2>&1; then
        # 检查是否是我们的服务
        if pgrep -f "node server.js" >/dev/null 2>&1; then
            return 0
        fi
    fi
    return 1
}

# 更新前端文件
update_frontend() {
    log_message "📦 更新前端文件..."
    
    if [ -f /root/zealman-app/scripts/update-frontend-on-boot.sh ]; then
        bash /root/zealman-app/scripts/update-frontend-on-boot.sh >> "$LOG_FILE" 2>&1
        if [ $? -eq 0 ]; then
            log_message "✅ 前端文件更新成功"
        else
            log_message "⚠️  前端文件更新失败，继续启动服务"
        fi
    else
        log_message "⚠️  前端更新脚本不存在，跳过更新"
    fi
}

# 启动服务
start_service() {
    log_message "🚀 启动 Zealman-app 服务..."
    
    # 切换到生产环境目录
    cd /root/zealman-app
    
    # 启动服务
    ./start-services.sh >> "$LOG_FILE" 2>&1
    
    # 等待服务启动
    local attempts=0
    local max_attempts=30
    
    while [ $attempts -lt $max_attempts ]; do
        if check_service; then
            log_message "✅ 服务启动成功"
            return 0
        fi
        sleep 1
        attempts=$((attempts + 1))
    done
    
    log_message "❌ 服务启动失败 - 超时"
    return 1
}

# 主函数
main() {
    # 检查锁文件
    if [ -f "$LOCK_FILE" ]; then
        local lock_pid=$(cat "$LOCK_FILE" 2>/dev/null)
        if [ -n "$lock_pid" ] && kill -0 "$lock_pid" 2>/dev/null; then
            log_message "🔒 启动脚本已在运行 (PID: $lock_pid)，跳过"
            exit 0
        else
            rm -f "$LOCK_FILE"
        fi
    fi
    
    # 创建锁文件
    echo $$ > "$LOCK_FILE"
    
    # 清理函数
    cleanup() {
        rm -f "$LOCK_FILE"
        exit $?
    }
    trap cleanup EXIT INT TERM
    
    # 检查服务状态
    if check_service; then
        log_message "✅ 服务已在运行"
        exit 0
    fi
    
    # 更新前端文件（已禁用）
    # update_frontend
    
    # 启动服务
    start_service
}

# 执行主函数
main "$@"
