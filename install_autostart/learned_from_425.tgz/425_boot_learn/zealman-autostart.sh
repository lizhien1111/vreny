#!/bin/bash
# Zealman-AutoDL 自动启动脚本
# 在所有用户登录时执行

if [ -f /root/zealman-app/scripts/improved-autostart.sh ]; then
    nohup bash /root/zealman-app/scripts/improved-autostart.sh > /tmp/zealman-profile-d.log 2>&1 &
fi
